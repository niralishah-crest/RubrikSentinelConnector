"""This __init__ file will be called once data is generated in webhook and
    it creates trigger."""
import json
import logging
import os
from datetime import datetime
from ..Shared_code.AzureSentinel import AzureSentinel
from ..Shared_code.RubrikException import RubrikException
import azure.functions as func

# fetch data from os environment
sentinel_log_type = os.environ.get("RansomwareAnalysis_table_name")


def main(request: func.HttpRequest) -> func.HttpResponse:
    """
    Start the execution.

    Args:
        request (func.HttpRequest): To get data from request body pushed
        by webhook

    Returns:
        func.HttpResponse: Status of Http request process (successful/failed).
    """
    logging.info(f"RansomwareAnalysis({datetime.now()}): Start processing...")

    try:
        logging.info(f"({datetime.now()}): Start getting data")
        webhook_data = request.get_json()
        logging.info(f"({datetime.now()}): Got data Successfully")
    except ValueError as value_error:
        logging.error(f"Error in RubrikRansomwareAnalysisEvent: {value_error}")
        return func.HttpResponse(
            f"RubrikRansomwareAnalysisEvent: {value_error}")
    except Exception as error:
        logging.error(f"Error in RubrikRansomwareAnalysisEvent: {error}")
        return func.HttpResponse(
                        f"Error in RubrikRansomwareAnalysisEvent: {error}")
    else:
        if webhook_data:
            body = json.dumps(webhook_data)
            logging.info("Got data of RansomwareAnalysis event via webhook.")
            try:
                logging.info(f"({datetime.now()}) Try to posting data...")
                azuresentinel = AzureSentinel()
                status_code = azuresentinel.post_data(
                    body,
                    sentinel_log_type,
                )
            except RubrikException as error:
                logging.error(error)
                return func.HttpResponse(error)
            else:
                if status_code >= 200 and status_code <= 299:
                    return func.HttpResponse(
                        "Data posted successfully from RansomwareAnalysisEvent"
                    )
                return func.HttpResponse(
                    "Failed to post data from RansomwareAnalysis into sentinel"
                )
