# This function an HTTP starter function for Durable Functions.
# Before running this sample, please:
# - create a Durable orchestration function
# - create a Durable activity function (default name is "Hello")
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt
 
import logging
import json
import azure.functions as func
import azure.durable_functions as df


async def main(req: func.HttpRequest, starter: str) -> func.HttpResponse:
    client = df.DurableOrchestrationClient(starter)
    try:
        data = req.get_json()
        # logging.info("body data from httpstart function: {}".format(data))
        data = json.dumps(data)
        # logging.info("data from httpstart function: {}".format(data))
        instance_id = await client.start_new(req.route_params["functionName"], client_input=data)
        logging.info(f"Started orchestration with ID = '{instance_id}'.")
        return client._create_http_response(status_code=200, body="")
    except ValueError as err:
        logging.error(err)
    except Exception as err:
        logging.error(err)
    