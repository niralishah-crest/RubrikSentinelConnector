# This function is not intended to be invoked directly. Instead it will be
# triggered by an HTTP starter function.
# Before running this sample, please:
# - create a Durable activity function (default name is "Hello")
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

import logging
import json
import os
import azure.functions as func
import azure.durable_functions as df

anomaly_log_type = os.environ.get("Anomalies_table_name")

def orchestrator_function(context: df.DurableOrchestrationContext):
    logging.info("RubrikAnomalyOrchestrator function called!")
    data = context.get_input()
    logging.info("data: {}".format(data))
    result1 = yield context.call_activity('RubrikActivity', {"data":data, "log_type":anomaly_log_type})
    logging.info("RubrikAnomalyOrchestrator function completed!")
    return result1

main = df.Orchestrator.create(orchestrator_function)