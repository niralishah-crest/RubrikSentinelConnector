# This function is not intended to be invoked directly. Instead it will be
# triggered by an orchestrator function.
# Before running this sample, please:
# - create a Durable orchestration function
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

import logging
from .sentinel import AzureSentinel

def main(name: dict) -> str:
    logging.info("Activity function called!")
    sentinel_obj = AzureSentinel()
    body = name.get("data")
    log_type = name.get("log_type")
    logging.info("data in activity function: {}".format(body))
    sentinel_obj.post_data(body, log_type)
    logging.info("Activity function Completed!")
    return "Activity Function Completed Successfully."
