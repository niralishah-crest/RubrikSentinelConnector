"""This __init__ file will be called by Orchastrator function to ingest data in Sentinel."""
import inspect
import time
from shared_code.logger import applogger
from shared_code.consts import LOGS_STARTS_WITH
from shared_code.rubrik_exception import RubrikException
from .sentinel import MicrosoftSentinel


def post_data_to_sentinel(name):
    """_summary_

    Args:
        name (_type_): _description_
    """
    __method_name = inspect.currentframe().f_code.co_name
    try:
        sentinel_obj = MicrosoftSentinel()
        body = name.get("data")
        log_type = name.get("log_type")
        sentinel_obj.post_data(body, log_type)
    except Exception as err:
        applogger.error("{}(method={}) {}".format(LOGS_STARTS_WITH, __method_name, err))
        raise RubrikException(err)
    
def main(name) -> str:
    """Start Execution of Activity Function.

    Args:
        name (dict): data received via Rubrik Webhook.

    Returns:
        str: status message of activity function.
    """
    __method_name = inspect.currentframe().f_code.co_name
    try:
        applogger.info("{}(method={}) Activity function called!".format(LOGS_STARTS_WITH, __method_name))
        start = time.time()
        post_data_to_sentinel(name)
        end = time.time()
        applogger.info(
                "{}(method={}) time taken for data ingestion is {} sec".format(
                    LOGS_STARTS_WITH, __method_name, int(end - start)
                )
            )
        applogger.info("Activity function Completed!")
    except RubrikException as err:
        return err
    except Exception as err:
        applogger.error("{}")
        return err
    return "Data Posted successfully to {}".format(name.get("log_type"))
